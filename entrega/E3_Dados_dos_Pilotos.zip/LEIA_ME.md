# Dados dos pilotos do UX-Agent

O artigo descreve os resultados por versão. Cada sessão ou tentativa tem um arquivo JSON com eventos e requisições. As instruções e observações estão em requests. O dicionário de eventos acompanha os dados.

- Versão 1.0: 17 tentativas com Codex. O manifesto contém as sessões da rodada.
- Versão 1.2: cinco tentativas independentes com Sol, Luna e Qwen3 local, todas na variante B e no perfil fixo. Os JSONs indicam modelo, tarefa, limite, ações e desfecho.
- Verificação dirigida: um percurso C4 feito por ações de teste no navegador. Este registro não entra no total do piloto com IA.

O vídeo E5 reproduz a tentativa C2 com GPT-6-Sol, versão 1.2, variante B. O arquivo c2-medio na pasta v1.2 contém as nove escolhas e o resultado exibidos.

O sucesso foi decidido pelo verificador. A exploração informal de um dos autores aparece no artigo e não foi contada como sessão humana de pesquisa.

# Tentativa C4 com GPT-6-Sol

Rodamos uma tentativa de C4 na interface 1.2.0, variante B, perfil fixo, semente 20261026 e raciocínio médio. Mantivemos os limites do motor usados em C2, de 40 ações ou 60 propostas.

Resultado externo: insucesso por limite. O agente fez 40 ações e recebeu ajuda 20 vezes. Ações observadas: Ajuda: 20, Voltar à tarefa: 20. A tentativa terminou sem resposta selecionada. Como não houve oportunidade funcional, a taxa de erros por oportunidade fica indefinida. A referência KLM de C4 prevê quatro ações em um caminho concluído.

Na mesma configuração, C2 teve sucesso em nove ações. Uma tentativa por tarefa descreve o que aconteceu em cada cenário. A repetição da ajuda em C4 é um resultado observado.

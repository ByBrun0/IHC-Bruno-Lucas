# Verificação local com Ollama

Usamos o Qwen3 4B Instruct já instalado, quantizado em Q4_K_M (2,5 GB), em um computador com RTX 3050 de 4 GB. O agente escolheu uma ação por chamada, em JSON, com temperatura zero. Cada tentativa começou em sessão própria, no perfil fixo, variante B e semente 20261026. Os limites de cinco chamadas para C4 e doze para C2 foram definidos antes da execução.

## C2

O agente atingiu o limite de chamadas sem concluir.
12 ações, 0 entregas de ajuda e 11 oportunidades funcionais. Marcas registradas: E3.

Ações: Item Alfa · 08:00 · 26/10/2026 → Alfa: Sem confirmação registrada · Beta: Sem confirmação registrada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada → Alfa: Sem confirmação registrada · Beta: Tomada relatada

## C4

O agente desistiu.
3 ações, 2 entregas de ajuda e 0 oportunidades funcionais. Marcas registradas: E4.

Ações: Ajuda → Entender os registros → Desistir

Foram duas tentativas exploratórias, sem cobrança de API. As observações, respostas e eventos estão nos JSONs. Os limites e a versão do aplicativo devem ser considerados ao comparar com o piloto anterior. Os resultados não identificam a causa das dificuldades.
